# modality

This is the CLI for Modality written in Rust.